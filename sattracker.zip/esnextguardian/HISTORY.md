# History

## v1.2.1 2016 January 15
- Repackaged

## v1.2.0 2015 December 9
- Debug environment variable is now `DEBUG_ESNEXTGUARDIAN` instead of `DEBUG`, is now documented, and is now used to warn when preferred practices are not followed

## v1.1.0 2015 September 18
- Better way of including the modules

## v1.0.2 2015 September 18
- Initial working version
- Added tests

## v1.0.1 2015 September 18
- Fixed typo

## v1.0.0 2015 September 18
- Ported from [bevry/base](https://github.com/bevry/base) to allow for easier adaption towards new environments
